/*
Configure assassin cast stack in this order at the TOP of the list
Assassinate
Concealment
Stealth Assault
Jugular Slice
Eviscerate
Mortal Blade
Massacre ; this needs to be last to tell the script when we are done with the concealment attack chain
*/

function main()
{
	echo (${Time}) Assassin Companion Script 69420
	call variables
	call StealthOff
	while 1
    {
		while ${Me.InCombat}==TRUE
		{
			if ${NewFight}==TRUE
			{
				NewFight:Set[FALSE]
				CombatStart:Set[${Time.Timestamp}]
			}
			if (${Me.Ability[id,3008295138].TimeUntilReady}<=12 && ${Me.Ability[id,866089504].TimeUntilReady}==0)
            {
                call refresh
                call StealthOn
                while ${Me.Ability[id,612007182].TimeUntilReady}==0 && ${Me.InCombat}==TRUE && (((${Target.Type.Equal["NamedNPC"]} || ${Target.Type.Equal["NPC"]}) && ${TargetDist}<=15) || ((${Target.Target.Type.Equal["NamedNPC"]} || ${Target.Target.Type.Equal["NPC"]}) && ${TargetTargetDist}<=15))
                    wait 10
                call StealthOff
                wait 10
            }
        }
        if !${NewFight}
            NewFight:Set[TRUE]
    }
}
function StealthOn()
{
	OgreBotAPI.CastStack:SetEntry[${Me.Name},"Assassinate",TRUE]
	while ${Me.Ability[id,1493017401].TimeUntilReady} < 10
		wait 10
    OgreBotAPI.CastStack:SetEntry[${Me.Name},"Concealment",TRUE]
	OgreBotAPI.CastStack:SetEntry[${Me.Name},"Stealth Assault",TRUE]
	OgreBotAPI.CastStack:SetEntry[${Me.Name},"Jugular Slice",TRUE]
	OgreBotAPI.CastStack:SetEntry[${Me.Name},"Eviscerate",TRUE]
	OgreBotAPI.CastStack:SetEntry[${Me.Name},"Mortal Blade",TRUE]
	OgreBotAPI.CastStack:SetEntry[${Me.Name},"Massacre",TRUE]	
	wait 20
}
function StealthOff()
{
	OgreBotAPI.CastStack:SetEntry[${Me.Name},"Concealment",FALSE]
	OgreBotAPI.CastStack:SetEntry[${Me.Name},"Jugular Slice",FALSE]
	OgreBotAPI.CastStack:SetEntry[${Me.Name},"Eviscerate",FALSE]
    OgreBotAPI.CastStack:SetEntry[${Me.Name},"Mortal Blade",FALSE]
	OgreBotAPI.CastStack:SetEntry[${Me.Name},"Assassinate",FALSE]
	OgreBotAPI.CastStack:SetEntry[${Me.Name},"Massacre",FALSE]
	wait 25
}
function variables()
{
	declare TargetTargetDist float script
	declare TargetDist float script
	declare MimicryTime int script 0
	declare PFTtimer int script 0
	declare ItemTimer int script 0
	declare CombatStart uint script
	declare NewFight bool script TRUE
	declare SHTime uint global
	declare SwapTime uint global
}
function refresh()
{
	TargetDist:Set[${Math.Calc[${Target.Distance}-(${Actor[${Target.ID}].CollisionRadius}*${Actor[${Target.ID}].CollisionScale}+${Me.CollisionRadius}*${Me.CollisionScale})]}]
	TargetTargetDist:Set[${Math.Calc[${Target.Target.Distance}-(${Actor[${Target.Target.ID}].CollisionRadius}*${Actor[${Target.Target.ID}].CollisionScale}+${Me.CollisionRadius}*${Me.CollisionScale})]}]
}
;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;
        ;     LIST OF ID'S           
;	Stealth Assault		204218481                  #
;   In Plain Sight	    3633058267                     #
;   FFU V			    3051745403                     #
;   Bleedout		    872584025                      #
;   Carnage		        4179643856                     #
;   Bloodflurry 		3085956600                     #
;   Stealth Assault	    866089504                      #
;   Gut		            971949777                      #
;   Assassinate VII     1493017401                     #
;   PFT                 2305497779                     #
;   concealment         3008295138                     #
;   Eviscerate          3949617436                     #
;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;
	
	