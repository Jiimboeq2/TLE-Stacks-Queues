TODO; edit script 
try messing with your export for the moment til i can find a work around.